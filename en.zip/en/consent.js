const consentCheckbox = document.getElementById('rgpd-consent');
const confirmButton = document.getElementById('confirm-btn');

// Activer/Désactiver le bouton en fonction de la case à cocher
consentCheckbox.addEventListener('change', () => {
  confirmButton.disabled = !consentCheckbox.checked;
});

// Gestion du clic sur le bouton de confirmation
confirmButton.addEventListener('click', () => {
  // Enregistrer le consentement dans chrome.storage
  chrome.storage.local.set({ consentGranted: true }, () => {
    // Redirige vers la page d'accueil ou ferme l'onglet
    window.close();
  });
});
