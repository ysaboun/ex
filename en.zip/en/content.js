// Vérifie que l'on est sur la page des résultats de recherche de Google
if (window.location.host === "www.google.com") {
  addRedirectionButtonToSearchResults();
}

// Écoute le message de background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message reçu : ", message);
  
  // Vérifier que l'action est "showCartPopup"
  if (message.action === 'showCartPopup') {
    showPopup();
    sendResponse({ status: 'Popup affichée' });
  } else {
    sendResponse({ status: 'Action non reconnue' });
  }
});

// Fonction pour ajouter le bouton
function addRedirectionButtonToSearchResults() {
  const results = document.querySelectorAll('.g'); // Ciblage des résultats de recherche
  results.forEach(result => {
    const link = result.querySelector('a');
    if (link) {
       // Créer le bouton de redirection
      const redirectButton = document.createElement('button');
      redirectButton.innerText = 'Cetelem Extension';
      redirectButton.classList.add('redirect-button'); // Ajoute une classe pour le style
       // Log pour vérifier que le bouton est créé
       console.log("Bouton créé : ", redirectButton);
      // Ajouter l'événement de clic au bouton
       redirectButton.addEventListener('click', () => {
        console.log("Hello cetelm");
        chrome.runtime.sendMessage({ action: 'redirectToExtension', url: link.href });
      });
      // Ajouter le bouton au DOM
      result.appendChild(redirectButton);
    }
  });
}

// Fonction pour afficher la popup
function showPopup() {
  // Créer un élément de popup
  const popup = document.createElement('div');
  popup.style.position = 'fixed';
  popup.style.bottom = '20px';
  popup.style.left = '50%';
  popup.style.transform = 'translateX(-50%)';
  popup.style.backgroundColor = '#28a745';
  popup.style.color = 'white';
  popup.style.padding = '15px';
  popup.style.borderRadius = '8px';
  popup.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
  popup.style.fontSize = '16px';
  popup.style.zIndex = '10000';
  popup.style.textAlign = 'center';
  popup.style.width = '300px';
  popup.style.cursor = 'pointer';
  popup.innerHTML = `Cetelem Extension, Vous êtes sur la page de votre panier !`;

  // Créer le bouton d'action
  const button = document.createElement('button');
  button.textContent = 'Passer à l\'étape suivante';
  button.style.backgroundColor = '#ffffff';
  button.style.color = '#28a745';
  button.style.border = '2px solid #28a745';
  button.style.padding = '10px 20px';
  button.style.fontSize = '14px';
  button.style.borderRadius = '8px';
  button.style.cursor = 'pointer';
  button.style.marginTop = '10px';

  // Ajouter l'événement de clic au bouton
  button.addEventListener('click', () => {
    // Action à faire au clic sur le bouton (par exemple, rediriger l'utilisateur)
    window.location.href = 'https://www.boulanger.com/checkout'; // Ou toute autre redirection
  });

  // Ajouter le bouton à la popup
  popup.appendChild(button);

  // Ajouter la popup au body
  document.body.appendChild(popup);

  // Optionnel : Ajouter un effet de disparition après quelques secondes
  /*setTimeout(() => {
    popup.style.opacity = '0';
    setTimeout(() => popup.remove(), 500);
  }, 10000);  // Après 10 secondes, la popup disparaît
  */
}

// Ajout du style CSS pour le bouton
const style = document.createElement('style');
style.textContent = `
  .redirect-button {
    background-color: #28a745; /* Vert agréable */
    color: white;
    font-size: 14px;
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    margin-left: 10px;
    transition: background-color 0.3s ease, transform 0.2s ease;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .redirect-button:hover {
    background-color: #218838; /* Vert plus foncé au survol */
    transform: scale(1.05);
  }

  .redirect-button:focus {
    outline: none;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
  }

  .redirect-button:active {
    background-color: #1e7e34; /* Vert encore plus foncé quand cliqué */
  }

  .popup-button {
    background-color: #ffffff;
    color: #28a745;
    border: 2px solid #28a745;
    padding: 10px 20px;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
    margin-top: 10px;
  }

  .popup-button:hover {
    background-color: #28a745;
    color: white;
  }
  
  .popup-button:focus {
    outline: none;
  }
`;
document.head.appendChild(style);
