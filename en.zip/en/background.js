/*chrome.webNavigation.onCompleted.addListener((details) => {
  const url = details.url;
  // Vérifie si on est sur un site de type "Boulanger"
  if (url.includes("boulanger.com")) {
    // Appelle executeScript pour exécuter le code sur la page spécifique
    chrome.scripting.executeScript({
      target: { tabId: details.tabId },
      func: detectPurchaseAction
    });
  }
  
});*/
chrome.runtime.onInstalled.addListener(() => {
  // Vérifie si le consentement a été donné
  chrome.storage.local.get('consentGranted', (data) => {
    if (!data.consentGranted) {
      // Ouvre la page de consentement
      chrome.tabs.create({ url: chrome.runtime.getURL('consent.html') });
    }
  });
});

chrome.webNavigation.onCompleted.addListener((details) => {
  chrome.storage.local.get('consentGranted', (data) => {
     const url = details.url;

    // Utilisation d'expressions régulières pour vérifier les URLs contenant "/cart/" sur amazon.fr et boulanger.com
    const amazonCartPattern = /^https:\/\/www\.amazon\.fr\/cart\//;
    const boulangerCartPattern = /^https:\/\/www\.boulanger\.com\/checkout\/cart\//;

    if (amazonCartPattern.test(url) || boulangerCartPattern.test(url)) {
      // Injecter le script content.js dans la page
      chrome.scripting.executeScript({
        target: { tabId: details.tabId },
        files: ['content.js']
      }, () => {
        console.log('Script content.js injecté avec succès !');
        // Vérifie si l'onglet est valide avant d'envoyer le message
        if (details.tabId !== undefined) {
          console.log("TabId trouvé : ", details.tabId);
          
          // Envoie un message au contenu du script
        chrome.tabs.sendMessage(details.tabId, { action: 'showCartPopup' }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("Erreur lors de l'envoi du message : ", JSON.stringify(chrome.runtime.lastError));
          } else {
            console.log("Message envoyé et réponse reçue :", response);
          }
        });
      } else {
            console.error("TabId est indéfini ou invalide.");
      }
      });   
    }
  });
}, { url: [{ hostContains: 'amazon.fr' }, { hostContains: 'boulanger.com' }] });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'redirectToExtension') {
    console.log("Message reçu pour rediriger : ", message.url);
    // Ouvrir un nouvel onglet vers l'URL envoyée
    chrome.tabs.create({ url: message.url });
  }
});




// Fonction de détection d'une action d'achat (exemple simple)
function detectPurchaseAction() {
  const checkoutButton = document.querySelector('button.checkout'); // Remplacer par un sélecteur réel
  if (checkoutButton) {
    alert("Vous êtes sur le point de finaliser un achat sur Boulanger !");
  }
}
