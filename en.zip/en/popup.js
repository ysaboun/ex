// Attache un événement de clic au bouton
document.getElementById('openSite').addEventListener('click', function() {
    // Ouvre un nouvel onglet avec l'URL de Boulanger
    chrome.tabs.create({ url: "https://www.cetelem.fr" });
  });
  