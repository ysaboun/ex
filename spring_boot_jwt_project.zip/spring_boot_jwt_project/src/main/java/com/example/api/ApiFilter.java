package com.example.api;

import jakarta.servlet.FilterConfig;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class ApiFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialisation du filtre si nécessaire
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException{
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;

        // Extraire le JWT depuis l'en-tête Authorization
        String jwt = httpRequest.getHeader("Authorization");
        if (jwt == null || !jwt.startsWith("Bearer ")) {
            throw new SecurityException("Authorization header missing or invalid");
        }

        jwt = jwt.substring(7); // Retirer "Bearer " pour obtenir le token

        // Extraire l'empreinte du périphérique de l'en-tête
        String headersFingerprint = null;
        try {
            headersFingerprint = calculateFingerprint(httpRequest);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        // Décoder le JWT (en supposant qu'il est encodé en Base64)
        String[] jwtParts = jwt.split("\\."); // Diviser le JWT en ses parties : header, payload, signature
        if (jwtParts.length != 3) {
            throw new SecurityException("Invalid JWT format");
        }

        // Décoder le payload du JWT
        String payload = new String(Base64.getDecoder().decode(jwtParts[1]));
        JSONObject payloadJson = new JSONObject(payload);

        String jwsFingerprint = payloadJson.getString("device_fingerprint");

        System.out.println("jwsFingerprint = "+jwsFingerprint);
        System.out.println("headers Fingerprint calculé= "+headersFingerprint);

        // Comparer l'empreinte dans le JWT avec celle calculée à partir des en-têtes
        if (!headersFingerprint.equals(jwsFingerprint)) {
            throw new SecurityException("Fingerprint mismatch");
        }

        // Si tout est validé, passer la requête au prochain filtre ou servlet
        chain.doFilter(request, response);
    }

    public  String calculateFingerprint(HttpServletRequest request) throws NoSuchAlgorithmException {
        // Lire les en-têtes HTTP
        String userAgent = request.getHeader("User-Agent");
        String screenResolution = request.getHeader("Screen-Resolution");
        String languages = request.getHeader("Languages");
        String timeZone = request.getHeader("Time-Zone");

        // Afficher les en-têtes reçus
        System.out.println("User-Agent: " + userAgent);
        System.out.println("Screen-Resolution: " + screenResolution);
        System.out.println("Languages: " + languages);
        System.out.println("Time-Zone: " + timeZone);

        // Construire une chaîne unique
        String deviceInfo = String.join("|",
                userAgent != null ? userAgent : "",
                screenResolution != null ? screenResolution : "",
                languages != null ? languages : "",
                timeZone != null ? timeZone : ""
        );

        // Générer l'empreinte avec SHA-256
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(deviceInfo.getBytes(StandardCharsets.UTF_8));

        // Convertir le hash en chaîne hexadécimale
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        return hexString.toString();
    }

    @Override
    public void destroy() {
        // Libération des ressources si nécessaire
    }
}
